const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  orderId: { type: String, required: true, unique: true },
  baseAmount: { type: Number, required: true },     // nominal asli, mis. 50000
  uniqueAmount: { type: Number, required: true, index: true }, // nominal unik, mis. 50012
  status: { type: String, enum: ['pending', 'success', 'expired'], default: 'pending' },
  qrImage: { type: String }, // base64 data URL
  paidAt: { type: Date },
  createdAt: { type: Date, default: Date.now },
});

// TTL index PARSIAL: cuma transaksi yang statusnya masih "pending" yang auto-kehapus
// 15 menit setelah dibuat. Transaksi "success"/"expired" tetap disimpan permanen
// biar muncul terus di halaman Riwayat.
transactionSchema.index(
  { createdAt: 1 },
  { expireAfterSeconds: 900, partialFilterExpression: { status: 'pending' } }
);

module.exports = mongoose.models.Transaction || mongoose.model('Transaction', transactionSchema);
