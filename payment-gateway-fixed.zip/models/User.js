const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  businessName: { type: String, required: true },
  whatsapp: { type: String, required: true, unique: true, index: true },
  passwordHash: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.User || mongoose.model('User', userSchema);
