require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const { convertStaticToDynamic } = require('./utils/qris');
const Transaction = require('./models/Transaction');

const app = express();
app.use(express.json());
// jaga-jaga kalau MacroDroid kirim body sebagai plain text, bukan JSON
app.use(express.text({ type: ['text/*', 'application/x-www-form-urlencoded'] }));
app.use(express.static('public'));

// Koneksi MongoDB di-cache biar aman dipakai di lingkungan serverless (Vercel):
// tiap function invocation gak bikin koneksi baru terus-terusan.
let cached = global._mongooseConn;
if (!cached) cached = global._mongooseConn = { conn: null, promise: null };

async function connectDB() {
  if (cached.conn) return cached.conn;
  if (!cached.promise) {
    cached.promise = mongoose.connect(process.env.MONGODB_URI).then((m) => {
      console.log('MongoDB terhubung');
      return m;
    });
  }
  cached.conn = await cached.promise;
  return cached.conn;
}

// pastikan DB konek dulu sebelum request diproses
app.use(async (req, res, next) => {
  try {
    await connectDB();
    next();
  } catch (err) {
    console.error('Gagal konek MongoDB:', err);
    res.status(500).json({ error: 'Gagal konek ke database' });
  }
});

const QRIS_STATIS = process.env.QRIS_STATIS_STRING;

// 1) Kasir minta QR dengan nominal tertentu
app.post('/generate-qr', async (req, res) => {
  try {
    const { amount } = req.body;
    if (!amount || isNaN(amount)) {
      return res.status(400).json({ error: 'amount wajib diisi angka' });
    }

    // Bikin nominal unik (base + 100-999) biar gampang dicocokkan ke notif masuk,
    // dan dicek dulu belum dipakai transaksi pending lain
    let uniqueAmount;
    let bentrok = true;
    while (bentrok) {
      const suffix = Math.floor(Math.random() * 900) + 100;
      uniqueAmount = Number(amount) + suffix;
      bentrok = await Transaction.exists({ uniqueAmount, status: 'pending' });
    }

    const qrisDinamis = convertStaticToDynamic(QRIS_STATIS, uniqueAmount);
    const qrImage = await QRCode.toDataURL(qrisDinamis);

    const orderId = uuidv4();
    await Transaction.create({ orderId, baseAmount: amount, uniqueAmount, qrImage });

    res.json({ orderId, uniqueAmount, qrImage });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// 2) Webhook dipanggil MacroDroid tiap ada notif GoPay/DANA/OVO masuk
app.post('/webhook/payment', async (req, res) => {
  try {
    const rawText =
      typeof req.body === 'string'
        ? req.body
        : req.body.notification || JSON.stringify(req.body);

    console.log('Notifikasi masuk:', rawText);

    // Contoh notif: "Rp50.012 diterima" -> ambil 50012
    const match = rawText.match(/Rp\s*([\d.,]+)/i);
    if (!match) {
      return res.status(400).json({ error: 'Nominal tidak ditemukan di notifikasi' });
    }
    const nominal = Number(match[1].replace(/[.,]/g, ''));

    const trx = await Transaction.findOneAndUpdate(
      { uniqueAmount: nominal, status: 'pending' },
      { status: 'success', paidAt: new Date() },
      { new: true }
    );

    if (!trx) {
      return res
        .status(404)
        .json({ error: `Tidak ada transaksi pending dengan nominal Rp${nominal}` });
    }

    console.log(`Transaksi ${trx.orderId} LUNAS (Rp${nominal})`);
    res.json({ success: true, orderId: trx.orderId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// 3) Dipakai halaman kasir buat polling status pembayaran
app.get('/status/:orderId', async (req, res) => {
  const trx = await Transaction.findOne({ orderId: req.params.orderId });
  if (!trx) return res.status(404).json({ error: 'Order tidak ditemukan' });
  res.json({ status: trx.status, uniqueAmount: trx.uniqueAmount, paidAt: trx.paidAt });
});

// Saat jalan lokal (npm start / npm run dev) -> buka port biasa.
// Saat di-deploy ke Vercel -> Vercel yang panggil `app` langsung, jadi listen() dilewati.
if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Server jalan di port ${PORT}`));
}

module.exports = app;
